#
# Utility library for Red Hat Virtualization
#
require 'ovirtsdk4'

module Library
  module Utils
    class RHV_Disk
      def initialize(ems, handle = $evm)
        @debug      = true
        @handle     = handle
        @ems        = ems_to_service_model(ems)
        @connection = connection(@ems)
      end
      
      def list_disks(vm)
        disks = []
        vm_sdk = find_vm_by_name(vm.name)
        disk_attachments_service(vm_sdk.id).list.each do |disk_attachment|
          disks << @connection.follow_link(disk_attachment.disk)
        end
      end
      
      def add_disk(vm, name, size_in_gb, sparse=true)
        @handle.log(:info, "Adding disk name: #{name}, size: #{size_in_gb}GB to VM: #{vm.name}, sparse: #{sparse} ")
        vm_sdk = find_vm_by_name(vm.name)
        disk_attachment = disk_attachments_service(vm_sdk.id).add(
          OvirtSDK4::DiskAttachment.new(
            disk: {
              name: name,
              description: "Added by CloudForms",
              format: sparse ? OvirtSDK4::DiskFormat::COW : OvirtSDK4::DiskFormat::RAW,
              sparse: sparse,
              provisioned_size: size_in_gb.to_i * 2**30,
              storage_domains: [{
                id: default_storage_domain(vm_sdk).id
              }]
            },
            interface: OvirtSDK4::DiskInterface::VIRTIO,
            bootable: false,
            active: true
          )
        )
        disk_attachment.disk.id
      end
        
      def disk_ready?(disk_id)  
        disk = disk_service(disk_id).get
        disk.status == OvirtSDK4::DiskStatus::OK
      end

      private
      
      def find_vm_by_name(vm_name)
        vms_service.list(:search => "name=#{vm_name}").first
      end
      
      def default_storage_domain(vm_sdk)
        # Find and return the storage domain for the VM's bootable disk
        disk_attachments_service(vm_sdk.id).list.each do |disk_attachment|
          if disk_attachment.bootable
            disk = @connection.follow_link(disk_attachment.disk)
            return disk.storage_domains.first
          end
        end
      end

      def ems_to_service_model(ems)
        raise "Invalid EMS" if ems.nil?
        # ems could be a numeric id or the ems object itself
        unless ems.kind_of?(DRb::DRbObject) && /Manager/.match(ems.type.demodulize)
          if ems.to_s =~ /^\d{1,13}$/
            ems = @handle.vmdb(:ems, ems)
          end
        end
        ems
      end

      def storage_domains_service
        @connection.system_service.storage_domains_service
      end

      def disks_service
        @connection.system_service.disks_service
      end
      
      def disk_service(disk_id)
        disks_service.disk_service(disk_id)
      end
      
      def vms_service
        @connection.system_service.vms_service
      end

      def vm_service(vm_id)
        vms_service.vm_service(vm_id)
      end

      def disk_attachments_service(vm_id)
        vm_service(vm_id).disk_attachments_service
      end

      def connection(ems)
        connection = OvirtSDK4::Connection.new(
          :url      => "https://#{ems.hostname}/ovirt-engine/api",
          :username => ems.authentication_userid,
          :password => ems.authentication_password,
          :insecure => true
        )
        connection if connection.test(true)
      end
    end
  end
end

