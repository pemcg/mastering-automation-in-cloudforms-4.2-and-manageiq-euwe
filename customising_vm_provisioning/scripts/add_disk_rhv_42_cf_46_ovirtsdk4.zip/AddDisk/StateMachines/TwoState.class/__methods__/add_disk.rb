NEW_DISK_SIZE = 10
#
# This method needs to provide 4 variables to the add_disk call:
# vm: the CloudForms VM object on which to attach the new disk
# name: the name of the new disk
# disk_size_gb: the size of the new disk in GBytes
# sparse: a boolean indicating whether the new disk is to be created as thin provisioned (sparse=true)
#          or preallocated (sparse=false)
#
case $evm.root['vmdb_object_type']
when 'miq_provision'                  # called from a VM provision workflow
  vm = $evm.root['miq_provision'].destination
  disk_size_gb = NEW_DISK_SIZE
  sparse = true
when 'vm'
  vm = $evm.root['vm']                # called from a button
  disk_size_gb = $evm.root['dialog_disk_size_gb'].to_i
  sparse       = $evm.root['dialog_sparse'] == 'thin' ? true : false
end
ems = vm.ext_management_system
# Add the disk
disk_id = Library::Utils::RHV_Disk.new(ems).add_disk(vm, "new_disk", disk_size_gb, sparse)
# Save the IDs for the next state
$evm.set_state_var(:ems_id, ems.id)
$evm.set_state_var(:disk_id, disk_id)
