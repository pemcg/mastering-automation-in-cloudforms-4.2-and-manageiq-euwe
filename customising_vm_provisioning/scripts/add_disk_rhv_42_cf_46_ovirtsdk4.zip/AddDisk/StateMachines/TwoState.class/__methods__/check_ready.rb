ems_id  = $evm.get_state_var(:ems_id)
disk_id = $evm.get_state_var(:disk_id)

if Library::Utils::RHV_Disk.new(ems_id).disk_ready?(disk_id)
  $evm.log(:info, "Disk added successfully")
else
  $evm.root['ae_result'] = 'retry'
  $evm.root['ae_retry_interval'] = '15.second'
end
exit MIQ_OK
